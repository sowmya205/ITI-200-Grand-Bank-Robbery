package bv;

public abstract class Escape {
	
	public abstract void escaping();
	
	}


