The game starts with you, the user as the main character, beginning at a start point (Bank Vault). 
You wake up from a daze only to realize you are trapped in a bank. 
The bank is dark and dreary and you wake up to see money in your hand. 
The money that you hold is enough to make you rich beyond your belief. 
You know in your cynical heart that you must keep the money. Your instinct then tells you must escape, 
it's only a matter of time before the police comes.

Acceptable commands: north - n, east - e, west - w, and south - s

The correct order for winning the game is:
1.Solve the vault code to get out of the vault 
2.Walk into the office- solve the password to get the key 
3.Go into the computer room where you are tasked with riddle to solve
4.Go into the mail room and choose your choices wisely when choosing the right envelope to exit
5. eventually get to the lobby with your loot of money to win the game!
Failing to achieve the feat of exiting the rooms in the alloted chances will cause the game to end and the police will get called,remember you are a robber:

The map of the bank:
-----------------------------------------------------------------------------------------------------------
			|                 |					  |             |
	Vault	|   Office		  |	  Computer Room	  | Mail Room   |   Lobby
____________|_________________|___________________|____________ |__________________
Key: Code   | Key: Password   | Key: Riddle Answer| Key: Right Envelope
____________|_________________|___________________|_____________________________														
